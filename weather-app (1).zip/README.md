# weather-app

Simple Node.js CLI to fetch weather using Open-Meteo API.
