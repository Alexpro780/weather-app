#!/usr/bin/env node
import fetch from "node-fetch";

const city = process.argv[2] || "London";
const url = `https://api.open-meteo.com/v1/forecast?latitude=51.5&longitude=-0.1&current_weather=true`;

fetch(url).then(r=>r.json()).then(d=>{
    const temp = d.current_weather?.temperature;
    console.log(`Weather in ${city}: ${temp}°C`);
}).catch(e=>console.error(e));
